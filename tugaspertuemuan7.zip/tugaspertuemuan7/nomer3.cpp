#include<stdio.h>
#include<conio.h>
#include<iostream>
using namespace std;

int main ()
{
	int i, N, hasil, rerata;
	i=1;
	cout<<"masukan nilai N :";cin>>N;
	i=0;
	hasil=0;
	rerata=0;
	do
	{
		hasil+=i;
		i++;
	}
	while (i<=N);
	cout<<"jumlah bilangan dari 1 sampai N : "<<hasil<<endl;
	cout<<"nilai rerata:"<<endl;
	do
{
rerata=hasil/N;
cout<<rerata<<endl;
}
while (rerata>=i);
return 0;
}
