#include<stdio.h>
#include<conio.h>
#include<iostream>
using namespace std;

int main ()
{
	int i, N, jum_bil;
	cout<<"masukan nilai N :";cin>>N;
	i=0;
	jum_bil=0;
	do
	{
		jum_bil+=i;
		i++;
	}
	while (i<=N);
	cout<<"jumlah bilangan 1 sampai dengan N:"<< jum_bil<<endl;
}

