#include<stdio.h>
#include<conio.h>
#include<iostream>
using namespace std;

int main ()
{
	int i;
	i=125;
	cout<<"bilangan kelipatan 5 antara 125 sampai 200"<<endl;
	do
	{
		cout<<i<<endl;
		 i+=5;
	}
	while (i<=200);
}

